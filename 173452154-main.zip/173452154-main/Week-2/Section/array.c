#include <cs50.h>
#include <stdio.h>

void print(int array[]);
int main(void)
{
    int i = 0;
    int twice[i];
    twice[i] = 1;
    twice[i + 1] = 2 * twice[i];

    void print(twice[i]);
}

void print(int array[])
{
    for(int j = 0; j > 0; j++)
    {
        printf("%i, array[%i]\n", array[j], j);
    }
}
