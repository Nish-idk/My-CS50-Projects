#include <stdio.h>

int main(void)
{
    int c;
    printf("%i\n", c);
}
