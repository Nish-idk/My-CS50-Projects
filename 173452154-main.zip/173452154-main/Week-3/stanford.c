int *x;
int *y;

int n = 2;
y = &n;
x = y;
