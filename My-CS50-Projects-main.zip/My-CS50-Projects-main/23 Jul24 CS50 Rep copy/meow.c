#include<stdio.h>

int main(void)
{
    int i = 6;
    while (i > 0)
    {
        printf("meow\n");
        i = i - 1;
    }
}
