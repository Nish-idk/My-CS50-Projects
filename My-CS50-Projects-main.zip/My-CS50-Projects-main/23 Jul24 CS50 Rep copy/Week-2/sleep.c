#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int i = 0;
    int night[i];
    int hours = get_int("hours you slept: ");

    while(i >= 0)
    {
        night[i] = hours;
        i++
    }
}
