#include<stdio.h>
#include <cs50.h>

int main(void)
{
   int i = 3;
   for( ; ; i--)
   {
    printf("meow\n");
   }
}
